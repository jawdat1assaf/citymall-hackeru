"use strict";
exports.id = 5030;
exports.ids = [5030];
exports.modules = {

/***/ 8270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);

const withAuth = (handler)=>{
    return (req, res)=>{
        if (!req.headers["authorization"]) return res.status(401).json({
            message: "Invalid Token"
        });
        const [type, token] = req.headers["authorization"]?.split(" ");
        if (type !== "Bearer" || !token) {
            return res.status(403).json({
                message: "A token is required for authentication"
            });
        }
        try {
            const decoded = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().verify(token, process.env.JWT_SECRET_KEY);
            req.user = decoded;
        } catch (err) {
            return res.status(401).json({
                message: "Invalid Token"
            });
        }
        return handler(req, res);
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (withAuth);


/***/ }),

/***/ 5092:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _User__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6082);


const FriendRequest = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    _id: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
    from: {
        type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
        ref: _User__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
    },
    to: {
        type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
        ref: _User__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
    }
}).index({
    from: 1,
    to: 1
}, {
    unique: true
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.FriendRequest) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("FriendRequest", FriendRequest));


/***/ })

};
;