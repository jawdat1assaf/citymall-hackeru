"use strict";
exports.id = 5178;
exports.ids = [5178];
exports.modules = {

/***/ 4480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    throw new Error("Please define the MONGODB_URI environment variable inside .env.local");
}
/**
 * Global is used here to maintain a cached connection across hot reloads
 * in development. This prevents connections growing exponentially
 * during API Route usage.
 */ let cached = global.mongoose;
if (!cached) {
    cached = global.mongoose = {
        conn: null,
        promise: null
    };
}
async function dbConnect() {
    if (cached.conn) {
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        cached.promise = mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGODB_URI, opts).then((mongoose)=>{
            return mongoose;
        });
    }
    cached.conn = await cached.promise;
    return cached.conn;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);


/***/ }),

/***/ 6521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Product)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(1017);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
;// CONCATENATED MODULE: ./uploadDirectories.ts
const uploadDirectories = {
    user: "images/user",
    product: "images/product"
};


;// CONCATENATED MODULE: ./utilities/utility.ts
const path = __webpack_require__(1017);
const getPath = (restPath)=>{
    if (true) {
        return path.join("https://e-mobile-jawdat.herokuapp.com", restPath);
    }
    return "http://" + path.join(`0.0.0.0:${process.env.PORT}`, restPath);
};


;// CONCATENATED MODULE: ./models/Product.ts




const ProductSchema = new (external_mongoose_default()).Schema({
    _id: (external_mongoose_default()).Schema.Types.ObjectId,
    name: String,
    price: Number,
    image: String
});
ProductSchema.set("toJSON", {
    virtuals: true
});
ProductSchema.virtual("imagePath").get(function() {
    return this.image ? getPath(external_path_default().join(uploadDirectories.product, this.image)) : null;
});
/* harmony default export */ const Product = ((external_mongoose_default()).models.Product || external_mongoose_default().model("Product", ProductSchema));


/***/ })

};
;