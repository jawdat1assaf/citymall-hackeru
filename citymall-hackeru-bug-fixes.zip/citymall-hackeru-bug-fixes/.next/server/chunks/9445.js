"use strict";
exports.id = 9445;
exports.ids = [9445];
exports.modules = {

/***/ 9445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_AdminLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./layouts/NavBar.tsx


const NavBar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row flex-wrap items-center bg-secondary p-6 border-b border-gray-300",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex-none w-56 flex flex-row items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/logo.png",
                        className: "flex-none rounded-md",
                        height: 70,
                        width: 70
                    }),
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "ml-3 text-white",
                        children: "E-Mobile"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                id: "navbar",
                className: "animated flex-1 pl-3 flex justify-between items-center md:items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-gray-600",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "mr-2 transition duration-500 ease-in-out hover:text-gray-900",
                                href: "#",
                                title: "email",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fad fa-envelope-open-text"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "mr-2 transition duration-500 ease-in-out hover:text-gray-900",
                                href: "#",
                                title: "email",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fad fa-comments-alt"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "mr-2 transition duration-500 ease-in-out hover:text-gray-900",
                                href: "#",
                                title: "email",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fad fa-check-circle"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "mr-2 transition duration-500 ease-in-out hover:text-gray-900",
                                href: "#",
                                title: "email",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fad fa-calendar-exclamation"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-row-reverse items-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "dropdown relative md:static",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    className: "menu-btn focus:outline-none focus:shadow-outline flex flex-wrap items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-8 h-8 overflow-hidden rounded-full"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "ml-2 capitalize flex ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                className: "text-sm font-semibold m-0 p-0 leading-none text-white",
                                                children: "Username"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "hidden fixed top-0 left-0 z-10 w-full h-full menu-overflow"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-gray-500 menu hidden md:mt-10 md:w-full rounded bg-white shadow-md absolute z-20 right-0 w-40 mt-5 py-2 animated faster",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out",
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fad fa-user-edit text-xs mr-1"
                                                }),
                                                "edit my profile"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out",
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fad fa-inbox-in text-xs mr-1"
                                                }),
                                                "my inbox"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out",
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fad fa-badge-check text-xs mr-1"
                                                }),
                                                "tasks"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out",
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fad fa-comment-alt-dots text-xs mr-1"
                                                }),
                                                "chats"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out",
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fad fa-user-times text-xs mr-1"
                                                }),
                                                "log out"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_NavBar = (NavBar);

;// CONCATENATED MODULE: ./layouts/SideBar.tsx

const SideBar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "sideBar",
        className: "relative flex flex-col flex-wrap bg-white border-r border-gray-300 p-6 flex-none w-64 animated faster",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "/admin",
                    className: "mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fad fa-chart-pie text-xs mr-2"
                        }),
                        "Dashboard"
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "uppercase text-xs text-gray-600 mb-4 mt-4 tracking-wider",
                    children: "Users"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "/admin/user",
                    className: "mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fad fa-envelope-open-text text-xs mr-2"
                        }),
                        "Users"
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "uppercase text-xs text-gray-600 mb-4 mt-4 tracking-wider",
                    children: "General"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "/admin/product",
                    className: "mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fad fa-envelope-open-text text-xs mr-2"
                        }),
                        "Products"
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "/admin/order",
                    className: "mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fad fa-envelope-open-text text-xs mr-2"
                        }),
                        "Orders"
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "/admin/review",
                    className: "mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fad fa-envelope-open-text text-xs mr-2"
                        }),
                        "Reviews"
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: "/admin/logout",
                    className: "my-3 capitalize font-medium text-sm py-2 rounded-md px-5 bg-primary text-white text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa-solid fa-arrow-right-from-bracket text-xs mr-2"
                        }),
                        "Logout"
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layouts_SideBar = (SideBar);

;// CONCATENATED MODULE: ./layouts/AdminLayout.tsx



const AdminLayout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layouts_NavBar, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "h-screen flex flex-row flex-wrap",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(layouts_SideBar, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-gray-100 flex-1 p-6",
                        children: children
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layouts_AdminLayout = (AdminLayout);


/***/ })

};
;