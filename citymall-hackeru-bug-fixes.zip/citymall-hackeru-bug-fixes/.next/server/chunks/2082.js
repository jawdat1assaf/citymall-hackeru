"use strict";
exports.id = 2082;
exports.ids = [2082];
exports.modules = {

/***/ 3320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const CartSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    items: [
        {
            type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
            ref: "CartItem",
            optional: true,
            autopopulate: true
        }
    ]
});
CartSchema.plugin(__webpack_require__(314));
CartSchema.set("toJSON", {
    virtuals: true
});
CartSchema.virtual("total").get(function() {
    return this.items.reduce((total, item)=>total + item.sub_total, 0);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Cart) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Cart", CartSchema));


/***/ }),

/***/ 6470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const CartItemSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    product: {
        type: (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema.Types.ObjectId),
        ref: "Product",
        autopopulate: true
    },
    quantity: Number
});
CartItemSchema.plugin(__webpack_require__(314));
CartItemSchema.set("toJSON", {
    virtuals: true
});
CartItemSchema.virtual("sub_total").get(function() {
    return this.product?.price * this.quantity;
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.CartItem) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("CartItem", CartItemSchema));


/***/ })

};
;