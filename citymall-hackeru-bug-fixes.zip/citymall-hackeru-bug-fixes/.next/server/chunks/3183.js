"use strict";
exports.id = 3183;
exports.ids = [3183];
exports.modules = {

/***/ 3183:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Product)
});

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1185);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(1017);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
// EXTERNAL MODULE: ./uploadDirectories.ts
var uploadDirectories = __webpack_require__(4656);
;// CONCATENATED MODULE: ./utilities/utility.ts
const path = __webpack_require__(1017);
const getPath = (restPath)=>{
    if (true) {
        return path.join("https://e-mobile-jawdat.herokuapp.com", restPath);
    }
    return "http://" + path.join(`0.0.0.0:${process.env.PORT}`, restPath);
};


;// CONCATENATED MODULE: ./models/Product.ts




const ProductSchema = new (external_mongoose_default()).Schema({
    _id: (external_mongoose_default()).Schema.Types.ObjectId,
    name: String,
    price: Number,
    image: String
});
ProductSchema.set("toJSON", {
    virtuals: true
});
ProductSchema.virtual("imagePath").get(function() {
    return this.image ? getPath(external_path_default().join(uploadDirectories/* uploadDirectories.product */.P.product, this.image)) : null;
});
/* harmony default export */ const Product = ((external_mongoose_default()).models.Product || external_mongoose_default().model("Product", ProductSchema));


/***/ }),

/***/ 4656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ uploadDirectories)
/* harmony export */ });
const uploadDirectories = {
    user: "images/user",
    product: "images/product"
};



/***/ })

};
;