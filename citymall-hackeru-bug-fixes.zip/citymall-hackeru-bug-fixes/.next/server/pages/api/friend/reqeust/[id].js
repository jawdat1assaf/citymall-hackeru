"use strict";
(() => {
var exports = {};
exports.id = 5662;
exports.ids = [5662];
exports.modules = {

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 314:
/***/ ((module) => {

module.exports = require("mongoose-autopopulate");

/***/ }),

/***/ 6609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_dbConnect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4883);
/* harmony import */ var _middlewares_withAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8270);
/* harmony import */ var _models_FriendRequest__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5092);
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6082);




const handler = async (req, res)=>{
    const { method  } = req;
    await (0,_lib_dbConnect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
    switch(method){
        case "DELETE":
            try {
                const { deletedCount  } = await _models_FriendRequest__WEBPACK_IMPORTED_MODULE_2__/* ["default"].deleteOne */ .Z.deleteOne({
                    _id: req.query.id
                });
                if (deletedCount > 0) {
                    return res.status(204).json({
                        message: `Friend request deleted`
                    });
                }
                throw Error("Couldn't delete");
            } catch (err) {
                if (err.code === 11000) {
                    return res.status(400).json({
                        message: `Friend request has already been sent`
                    });
                }
                return res.status(400).json({
                    message: err.toString()
                });
            }
            break;
        case "PATCH":
            try {
                const friendRequest = await _models_FriendRequest__WEBPACK_IMPORTED_MODULE_2__/* ["default"].findById */ .Z.findById(req.query.id);
                if (!friendRequest) {
                    return res.status(404).json({
                        message: `Friend request not found`
                    });
                }
                const newFriend = await _models_User__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findById */ .Z.findById(friendRequest.from);
                const user = await _models_User__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findById */ .Z.findById(req.user._id);
                if (user) {
                    user.friends.push(newFriend);
                    newFriend.friends.push(user);
                    user.save();
                    newFriend.save();
                    friendRequest.remove();
                }
                return res.send(user);
            } catch (err1) {
                if (err1.code === 11000) {
                    return res.status(400).json({
                        message: `Friend request has already been sent`
                    });
                }
                return res.status(400).json({
                    message: err1.toString()
                });
            }
        default:
            return res.status(405).json({
                success: false
            });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_middlewares_withAuth__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(handler));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6926,5030], () => (__webpack_exec__(6609)));
module.exports = __webpack_exports__;

})();