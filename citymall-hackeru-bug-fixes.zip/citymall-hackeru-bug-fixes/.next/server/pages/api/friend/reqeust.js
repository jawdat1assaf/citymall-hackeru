"use strict";
(() => {
var exports = {};
exports.id = 5577;
exports.ids = [5577];
exports.modules = {

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 314:
/***/ ((module) => {

module.exports = require("mongoose-autopopulate");

/***/ }),

/***/ 1226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_dbConnect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4883);
/* harmony import */ var _middlewares_withAuth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8270);
/* harmony import */ var _models_FriendRequest__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5092);




const handler = async (req, res)=>{
    const { method  } = req;
    await (0,_lib_dbConnect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
    switch(method){
        case "GET":
            try {
                const friendRequests = await _models_FriendRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].find */ .Z.find({
                    $or: [
                        {
                            "to": req.user._id
                        },
                        {
                            "from": req.user._id
                        }, 
                    ]
                }).populate([
                    "from",
                    "to"
                ]);
                return res.send(friendRequests);
            } catch (err) {
                return res.status(405).json({
                    message: err.toString()
                });
            }
            break;
        case "POST":
            const targetUserId = req.body.user_id;
            try {
                const newRequest = await _models_FriendRequest__WEBPACK_IMPORTED_MODULE_3__/* ["default"].create */ .Z.create({
                    _id: new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Types.ObjectId)(),
                    from: req.user,
                    to: targetUserId
                });
                return res.status(201).json({
                    message: `Friend request sent`,
                    newRequest
                });
            } catch (err1) {
                if (err1.code === 11000) {
                    return res.status(400).json({
                        message: `Friend request has already been sent`
                    });
                }
                return res.status(400).json({
                    message: err1.toString()
                });
            }
            break;
        default:
            return res.status(405).json({
                success: false
            });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_middlewares_withAuth__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(handler));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6926,5030], () => (__webpack_exec__(1226)));
module.exports = __webpack_exports__;

})();