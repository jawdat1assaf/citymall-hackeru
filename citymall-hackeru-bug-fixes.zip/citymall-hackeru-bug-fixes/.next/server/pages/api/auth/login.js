"use strict";
(() => {
var exports = {};
exports.id = 3908;
exports.ids = [3908];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 314:
/***/ ((module) => {

module.exports = require("mongoose-autopopulate");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 9539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_dbConnect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4883);
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6082);
/* harmony import */ var _models_Cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7717);
/* harmony import */ var _models_CartItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(252);
/* harmony import */ var _models_Product__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3183);







const handler = async (req, res)=>{
    const { method  } = req;
    await (0,_lib_dbConnect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    switch(method){
        case "POST":
            try {
                _models_User__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z;
                _models_Cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z;
                _models_CartItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z;
                _models_Product__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z;
                let user = await _models_User__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findOne */ .Z.findOne({
                    email: req.body.email
                }).exec();
                if (!user || !await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().compare(req.body.password, user.password)) return res.status(404).json({
                    message: "Credentials does not match with our records"
                });
                const access_token = jsonwebtoken__WEBPACK_IMPORTED_MODULE_1___default().sign(JSON.stringify({
                    email: user.email,
                    _id: user._id,
                    firstname: user.firstname,
                    lastname: user.lastname,
                    phone: user.phone
                }), process.env.JWT_SECRET_KEY);
                return res.send({
                    access_token,
                    user
                });
            } catch (err) {
                return res.status(400).json({
                    message: err.toString()
                });
            }
            break;
        default:
            return res.status(400).json({
                success: false
            });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6926,7674,3183], () => (__webpack_exec__(9539)));
module.exports = __webpack_exports__;

})();