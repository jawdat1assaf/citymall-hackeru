"use strict";
(() => {
var exports = {};
exports.id = 7007;
exports.ids = [7007];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 314:
/***/ ((module) => {

module.exports = require("mongoose-autopopulate");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 1333:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_dbConnect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4883);
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6082);
/* harmony import */ var _models_Cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7717);
/* harmony import */ var _models_CartItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(252);
/* harmony import */ var _models_Product__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3183);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction







const handler = async (req, res)=>{
    const { method  } = req;
    await (0,_lib_dbConnect__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    switch(method){
        case "POST":
            try {
                _models_User__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z;
                _models_Cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z;
                _models_CartItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z;
                _models_Product__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z;
                const cart = await _models_Cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"].create */ .Z.create({
                    items: []
                });
                const user = await _models_User__WEBPACK_IMPORTED_MODULE_3__/* ["default"].create */ .Z.create({
                    _id: new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Types.ObjectId)(),
                    firstname: req.body.firstname,
                    lastname: req.body.lastname,
                    phone: req.body.phone,
                    email: req.body.email,
                    password: await bcryptjs__WEBPACK_IMPORTED_MODULE_1___default().hash(req.body.password, 10),
                    wishlist: [],
                    cart: cart.id
                });
                return res.send(user);
            } catch (err) {
                return res.status(400).json({
                    message: err.toString()
                });
            }
            break;
        default:
            return res.status(400).json({
                success: false
            });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6926,7674,3183], () => (__webpack_exec__(1333)));
module.exports = __webpack_exports__;

})();