"use strict";
(() => {
var exports = {};
exports.id = 7790;
exports.ids = [7790];
exports.modules = {

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 314:
/***/ ((module) => {

module.exports = require("mongoose-autopopulate");

/***/ }),

/***/ 8270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_0__);

const withAuth = (handler)=>{
    return (req, res)=>{
        if (!req.headers["authorization"]) return res.status(401).json({
            message: "Invalid Token"
        });
        const [type, token] = req.headers["authorization"]?.split(" ");
        if (type !== "Bearer" || !token) {
            return res.status(403).json({
                message: "A token is required for authentication"
            });
        }
        try {
            const decoded = jsonwebtoken__WEBPACK_IMPORTED_MODULE_0___default().verify(token, process.env.JWT_SECRET_KEY);
            req.user = decoded;
        } catch (err) {
            return res.status(401).json({
                message: "Invalid Token"
            });
        }
        return handler(req, res);
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (withAuth);


/***/ }),

/***/ 5952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_dbConnect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4883);
/* harmony import */ var _middlewares_withAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8270);
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6082);



const handler = async (req, res)=>{
    const { method  } = req;
    const productId = req.query.productId;
    await (0,_lib_dbConnect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
    switch(method){
        case "PATCH":
            try {
                const user = await _models_User__WEBPACK_IMPORTED_MODULE_2__/* ["default"].findById */ .Z.findById(req.user._id);
                user.wishlist.pop(productId);
                await user.save();
                return res.send({
                    user
                });
            } catch (err) {
                return res.status(400).json({
                    message: err.toString()
                });
            }
            break;
        default:
            return res.status(400).json({
                success: false
            });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_middlewares_withAuth__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(handler));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6926], () => (__webpack_exec__(5952)));
module.exports = __webpack_exports__;

})();