const uploadDirectories = {
    user: 'images/user',
    product: 'images/product'
}

export { uploadDirectories };